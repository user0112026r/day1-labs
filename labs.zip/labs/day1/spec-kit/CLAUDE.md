# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this repo is

Spec Kit is a content-plus-CLI project. The `specify` CLI (Python, `src/specify_cli/`) bootstraps projects for Spec-Driven Development. The workflow itself lives in Markdown prompts and shell/PowerShell/Python scripts that the CLI copies into a user's project and into each supported AI agent's command directory.

Before touching a subsystem, read the matching guide. `AGENTS.md` is the entry point and names the required reads:
- CLI commands: `design/shared.md` + `design/cli.md`
- MCP tools: `design/shared.md` + `design/mcp.md`
- Agent integrations: `design/integration.md`
- Workflow step types: `design/workflow-step.md`
- Extensions: `design/extension.md`
- Catalogs: `design/catalogs.md`
- Contribution and test policy: `CONTRIBUTING.md`

## Commands

Setup (run from the repo root; `uv` is required):

```bash
uv sync --extra test                 # creates .venv with test deps
```

Windows PowerShell uses `.\.venv\Scripts\python.exe` and `.\.venv\Scripts\specify.exe` in place of `.venv/bin/...`.

Tests. Run through the checkout's own interpreter so you don't import another worktree's editable install:

```bash
.venv/bin/python -m pytest tests -q                                  # full suite
.venv/bin/python -m pytest tests/test_agent_config_consistency.py -q # agent wiring checks
.venv/bin/python -m pytest tests/specify_cli/extensions/test_command_add.py::test_name -q  # single test
```

CI runs `uv run pytest -n auto` (pytest-xdist). `pyproject.toml` sets `--strict-markers` and `-v` by default.

Lint and checks (mirrors `.github/workflows/lint.yml`):

```bash
uvx ruff@0.15.0 check src tests
git ls-files -z -- '*.sh' | xargs -0 shellcheck --severity=error
```

Markdown lint uses `markdownlint-cli2` with `.markdownlint-cli2.jsonc`. Ruff also enforces `S602`/`S604`/`S605`, so `shell=True` needs an explicit `# noqa` with a reason.

Dependency audit: after changing `pyproject.toml` dependencies, regenerate the hashed snapshot or `Lint & dependency audit` fails:

```bash
uv pip compile pyproject.toml --extra test --universal --upgrade --generate-hashes --quiet --no-header --output-file .github/security-audit-requirements.txt
```

Manual end-to-end check of the CLI against a scratch project:

```bash
.venv/bin/specify init <temp-dir>/speckit-test --integration <agent>
```

## Architecture (big picture)

**Single source, copied at build time.** Prompt and template sources are `templates/commands/`, `templates/*-template.md`, and `scripts/{bash,powershell,python}/`. `pyproject.toml`'s `[tool.hatch.build.targets.wheel.force-include]` maps them, plus bundled extensions, presets, workflows, and catalog snapshots, into `specify_cli/core_pack/` inside the wheel. Edit the source directories, never a packaged copy. Bundled assets are what `specify init` uses offline.

**Three shared assets that are also installable.** `extensions/`, `presets/`, `workflows/`, and `bundles/` each contain first-party packages plus `catalog.json` / `catalog.community.json` discovery snapshots. `specify extension add`, `specify preset add`, and `specify init --preset` consume them.

**CLI layout (`src/specify_cli/`).** `__init__.py` is the Typer app for the `specify` entry point. Each real command lives in `command_<name>.py`. A group's `_commands.py` imports those modules explicitly, which triggers their decorators, and then attaches the group to the root app. Nested directories match real CLI namespaces (e.g. `extensions/catalog/`). Typer-free domain logic sits in modules without the `command_` prefix. Keep decorated handlers out of `_commands.py` and package `__init__.py`.

**Shared operation boundary.** Operations with more than one adapter put semantic validation, orchestration, and side effects in `_operation_<name>.py` (with optional `_operation_<name>_<phase>.py`). The CLI (`command_*.py`) and MCP (`mcp_*.py`, served by `mcp_server/` and `command_mcp.py`) both call that entry point with a typed request and get a typed outcome. Adapters never call or parse each other. Project directories are passed explicitly; shared code must not `os.chdir()`. The MCP inventory is explicit, not discovered.

**Agent integrations (`src/specify_cli/integrations/`).** One subpackage per AI assistant (`claude/`, `copilot/`, `gemini/`, `codex/`, `cursor_agent/`, …), each built on `base.py`. `__init__.py` holds `INTEGRATION_REGISTRY` and a `_register` that rejects duplicate keys. An integration declares how commands are delivered and in which output format, and it owns install/uninstall of its files. External adapter packages follow the contract in `design/integration.md`.

**Workflow engine (`src/specify_cli/workflows/`).** Workflows are sequences of typed steps. Subpackages hold step types (`step/`, with a step catalog), expression evaluation (`expressions/`), function steps (`function/`), and overlays (`overlay/`). New step types must follow `design/workflow-step.md` for registration, validation, execution, and resume.

**Other domains.** `extensions/` (manifest, lifecycle, transactional install/update/remove), `presets/`, `bundles/`, `artifacts/`, `authentication/` (GitHub, Azure DevOps, and Bitbucket providers), and `events/` (command event runs) each have their own domain module and matching `tests/specify_cli/<area>/` directory.

**Tests mirror source.** `tests/specify_cli/<area>/` mirrors the source tree. Command surfaces go in `test_command_<name>.py`, shared-operation logic in `test_operation_<name>.py`, and domain code in `test_<subject>.py` without the leading underscore. Cross-cutting checks live in `tests/` top level, `tests/contract/`, and `tests/workflows/`.

## Rules that aren't obvious from the code

- **PowerShell targets Windows PowerShell 5.1**, not pwsh 7. Every `.ps1` in `scripts/powershell/` and any generated PowerShell must work on 5.1, and it must match the Bash and Python behavior. Behavioral PowerShell changes need 5.1 evidence.
- **Behavioral changes need positive and negative tests.** Bug fixes need a regression test that fails before the fix and passes after. Prompt-only edits don't need invented tests.
- **Changes to slash-command behavior require manual testing** through a real agent, reported in the PR (see `CONTRIBUTING.md` → Manual testing).
- **Branch names** are `<type>/<issue>-<slug>` or `<type>/<slug>` with type `feat|fix|docs|community|chore`.
- **AI disclosure is continuous.** PR bodies, each agent-authored commit (an `Assisted-by:` trailer naming the agent, model, and autonomous/supervised mode), and each AI-generated PR comment all need their own disclosure. Read `CONTRIBUTING.md` → "Agent-authored Git and review activity" before committing or posting.
- **Dogfooding scaffolding is gitignored** (`.github/agents/`, `.github/prompts/`, `.specify/`, `specs/`, and similar). Don't commit output from those paths.
