<!--
  CLAUDE.template.md: organizational template for a repository's CLAUDE.md.

  HOW TO USE
  1. Copy this file to CLAUDE.md at the repo root (and to subdirectory CLAUDE.md files only where a
     module has its own stack, tests, or rules).
  2. Replace every <placeholder>. Delete each HTML comment block once its section is filled in.
     Delete any section that does not apply rather than leaving it empty.
  3. Verify every fact against the source before writing it: lockfiles, config files, CI workflows,
     and the code itself. A wrong command is worse than a missing one.
  4. Keep the file under about 300 lines. Link to deeper docs instead of copying them.

  PRINCIPLES
  - Only write what Claude cannot cheaply discover. Skip anything obvious from the file tree.
  - Every rule states its reason ("because ...") and, where possible, the test or lint rule that enforces it.
  - Prefer commands over counts and versions. "Run X to see the count" stays correct; a hard-coded number rots.
  - Name what is NOT there (no ORM, no migrations, no indexes) when a reader would otherwise assume it.
  - Separate verified facts from intentions. Mark known gaps explicitly so nobody "fixes" them by accident.
-->

# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

<!-- Keep the header above exactly as written; it is the standard prefix for CLAUDE.md files. -->

## 1. Project overview

<!-- One or two sentences: what the system does, who uses it, and its current stage (prototype, production, lab).
     Then one sentence naming the architecture style if it is not obvious. -->

<project name> is <what it does> for <audience>. It is a <stack summary, e.g. "FastAPI service with a React frontend">.

Authoritative design documents:
- [ARCHITECTURE.md](ARCHITECTURE.md): design and decisions
- [<behavior spec>](<spec file>): behavioral contracts that tests cover

## 2. Repository map

<!-- Only the modules that matter. One row per independently built or tested unit.
     Link each module to its own CLAUDE.md when it has one. -->

| Module | Stack | Test command | Own guidance |
|---|---|---|---|
| [<dir>/](<dir>/) | <language, framework> | `<exact command>` | [<dir>/CLAUDE.md](<dir>/CLAUDE.md) or "this file" |
| [<dir>/](<dir>/) | <language, framework> | `<exact command>` | <link or "this file"> |

Rule: root guidance covers repo-wide tooling and cross-module rules. Module files cover that module only.
Read the module file before editing inside that module.

## 3. Toolchain and versions

<!-- Do not copy version numbers from memory. Point to the authoritative file, and list only pins that
     are deliberate policy (for example, "Python 3.12 only, because X"). -->

- Source of truth: `<lockfile or manifest paths>`. When this section and a lockfile disagree, the lockfile wins.
- Required runtime: <language version and why, e.g. "3.12, pinned by .python-version">
- Required tooling: <package manager>, <linter>, <formatter>, <type checker if any>
- Environment setup: <one command, e.g. `uv sync --extra test`>

## 4. Commands

<!-- Exact, copy-pasteable. Group by the task a developer performs. Mark the working directory explicitly. -->

Setup (from `<dir>`):

```bash
<install command>
<env or config setup command, if any>
```

Run:

```bash
<dev server or entry point command>
```

Test:

```bash
<full test command>                          # full suite
<test command> <path>::<test_name>           # single test
<test command> --collect-only -q             # authoritative test count (optional)
```

Lint, format, type-check:

```bash
<lint command>
<format check command>
<type check command, if any>
```

Notes on commands:
- <Working directory or path quirk, e.g. "run pytest from backend/; from the root it collects nothing useful">
- <Environment trap, e.g. "must use the venv's interpreter; the global one imports another checkout">
- <Anything that is CI-only, e.g. "CI runs `<command>` with `-n auto`">

## 5. Architecture

<!-- The big picture only: layers, their allowed dependencies, and where each kind of logic goes.
     Describe it as a rule a reader can apply to a new file. -->

Layers, outermost first. A layer may import only from the layers below it.

| Layer | Path | Owns | Must not |
|---|---|---|---|
| Interface / routing | `<path>` | <HTTP/CLI/UI wiring, input mapping> | <contain SQL or business rules> |
| Services / domain | `<path>` | <business rules, orchestration> | <import the framework or the database driver> |
| Data access | `<path>` | <the only code that touches the database or external API> | <raise transport-level errors> |
| Cross-cutting | `<path>` | <config, logging, auth, error mapping> | <depend on feature code> |

Enforcement: <name the test or lint rule that checks these boundaries, e.g. `tests/test_architecture.py`>.
If there is no automated check, say so and treat the table as a review convention.

Where new code goes:
- New endpoint or command: <path>, then wire into <registration point>.
- New business rule: <path>.
- New persistence operation: <path>, returning <plain types, not framework objects>.

Key flows: [<diagram or doc link>](<link>). Read it before changing a flow you have not touched.

## 6. Data and state

<!-- Only if the project persists state. Describe the facts a reader would otherwise assume. -->

- Store: <engine, library, file location, how the path is configured>
- Schema: <where it is defined, and how it changes>
- Migrations: <none / tool name and command>. Do not invent a migration system if none exists.
- Indexes and constraints: <explicit list, including what is NOT enforced at the database level>
- Connection and transaction model: <per-request, pooled, etc.>. <Thread-safety assumptions>.
- Known gaps: <e.g. "no atomicity across check-then-write; accepted for single-user use">

## 7. Interfaces and contracts

<!-- The external surface: API endpoints, CLI flags, events, file formats. Keep it to what a client depends on. -->

| Method / command | Path / name | Auth | Success | Notes |
|---|---|---|---|---|
| <verb> | <path> | <public / token / none> | <code> | <non-obvious behavior> |

- Auth mechanism: <how it works, where it is applied (e.g. at router level), and the failure behavior>
- Error shape: <body structure, and any unusual cases>
- Known gaps in the contract: <documented-vs-actual mismatches. Do not "fix" these in docs without changing code.>

## 8. Configuration

| Variable / setting | Default | Effect | Failure mode |
|---|---|---|---|
| `<ENV_VAR>` | <default> | <effect> | <e.g. "empty disables auth" or "empty fails closed"> |

- Where configuration is read: <single module path>. Do not read env vars elsewhere.
- Caching and reload: <e.g. "cached per process; restart or cache_clear() to apply changes">
- Loading: <who loads .env, and how>

## 9. Conventions

<!-- Only conventions that are enforced or that differ from the language default. -->

- Naming: <rule>
- Formatting: <tool and config file>
- Imports and module boundaries: see section 5.
- Errors: <where domain errors are mapped to transport errors>
- Commits and branches: <format, e.g. "Conventional Commits" or "<type>/<issue>-<slug>">
- Commit trailers or disclosures required by this repo: <e.g. AI-assistance disclosure, Assisted-by trailer>

## 10. Testing policy

- Test layout: <directory map, one line each>
- Test layers: <unit / integration / end-to-end, and what each one uses (fakes, real DB, real browser)>
- Every behavioral change needs a test that covers the intended behavior and at least one negative case.
- Every bug fix needs a regression test that fails before the fix and passes after it.
- End-to-end suites: <command, and when to run them (e.g. "after any change that crosses the API boundary")>
- Tests that must not run in CI: <list, or "none">

## 11. Constraints and do-nots

<!-- Hard rules. Each one has a reason. Keep this list short; longer lists stop being read. -->

- **Dependencies:** <allowed stack>. Adding a runtime dependency requires a decision with the user, not a silent change.
  Reason: <e.g. "keeps the lab on the stdlib and FastAPI only">.
- **Secrets:** never commit or print secrets, tokens, or credentials. Use <where secrets live>.
- **<Domain rule>:** <rule>. Reason: <why>.
- **<Scope rule>:** <e.g. "do not add fields to the Task schema beyond the five defined in spec.md">. Reason: <why>.
- **Deprecated code:** <path>. Do not build new features on it. Reason: <what replaces it>.
- **Refactors:** ask before large refactors or structural moves.

## 12. Known gaps and open decisions

<!-- Things a future reader would otherwise "fix" or be surprised by. Each entry says whether it is accepted, planned, or open. -->

- <Gap>: <status: accepted / planned / open>. <one-line reason>.

## 13. Agents, subagents, and automation

<!-- Only list agents that exist in the repo. Mark external or lab-only agents clearly. -->

- `.claude/agents/<name>.md`: <role, when to use it, whether it can write>
- Automation that must not be run unattended: <e.g. "agents with write tools must not run in CI">
- MCP servers declared in `<.mcp.json path>`: <list, with what each one backs>

## 14. Maintenance of this file

- Update this file in the same PR as any change to a command, layer boundary, or contract it describes.
- Keep counts and version numbers out of prose unless a command in this file regenerates them.
- Review this file quarterly, or when a new module is added. Delete sections that no longer apply.

---

<!--
  QUALITY CHECKLIST (run before committing the filled-in file)
  [ ] Every command was run, or copied from a file that is run in CI.
  [ ] Every path and link resolves in the repo.
  [ ] Every "do not" has a reason, and enforcement is named where it exists.
  [ ] No version number or test count appears that was not read from a file or a command.
  [ ] No section is a generic development practice that any repo would have.
  [ ] No secret, personal detail, or machine-specific path appears.
  [ ] Length is about 300 lines or fewer, and module-specific detail lives in module CLAUDE.md files.
-->
