# Cursor Rules: Spec Kit

<!--
  Generated from the organizational CLAUDE.md template (CLAUDE.template.md), adapted for Cursor.
  Cursor loads project rules from .cursor/rules/*.mdc (or the legacy .cursorrules file), not from this
  file directly. To activate, split sections into .mdc files or copy this content into .cursorrules.
  Keep this file under about 150 lines: Cursor applies rules as context on every request.
-->

## 1. Project overview

Spec Kit is a toolkit for Spec-Driven Development. The `specify` CLI (Python, `src/specify_cli/`) bootstraps projects. The workflow lives in Markdown prompts (`templates/commands/`) and scripts (`scripts/{bash,powershell,python}/`) that the CLI copies into user projects and into each supported AI agent's command directory.

Authoritative guides, read the matching one before editing a subsystem:
- `AGENTS.md`: entry point and the required reads per subsystem
- `design/shared.md`, `design/cli.md`, `design/mcp.md`: CLI and MCP command architecture
- `design/integration.md`: agent integrations
- `design/workflow-step.md`: workflow step types
- `design/extension.md`, `design/catalogs.md`: extensions and catalogs
- `CONTRIBUTING.md`: contribution and test policy

## 2. Repository map

| Path | Role | Test command |
|---|---|---|
| `src/specify_cli/` | Python CLI | `.venv/bin/python -m pytest tests -q` |
| `templates/` | Command prompts and artifact templates | Covered by `tests/` |
| `scripts/` | bash, PowerShell, and Python helper scripts | Covered by `tests/` |
| `extensions/`, `presets/`, `workflows/`, `bundles/` | First-party packages with catalog snapshots | Covered by `tests/` |
| `tests/` | Mirrors `src/specify_cli/` | See section 10 |

Packaging: `pyproject.toml` copies the sources above into the wheel under `specify_cli/core_pack/`. Edit the source directories, never a packaged copy.

## 3. Toolchain

- Source of truth: `pyproject.toml` and `.github/security-audit-requirements.txt`. Read them rather than trusting this file.
- Python 3.11 or newer (`requires-python`). CI runs 3.11, 3.14, and 3.15 on pushes and pull requests, plus 3.12 and 3.13 on schedule.
- Package manager: `uv`.

## 4. Commands

Setup, from the repo root:

```bash
uv sync --extra test
```

Windows PowerShell uses `.\.venv\Scripts\python.exe` in place of `.venv/bin/python`.

Tests. Always run through the checkout's own interpreter so you don't import another worktree's install:

```bash
.venv/bin/python -m pytest tests -q                                   # full suite
.venv/bin/python -m pytest tests/test_agent_config_consistency.py -q  # agent wiring
.venv/bin/python -m pytest tests/specify_cli/extensions/test_command_add.py::test_name -q  # one test
```

Lint and checks (mirrors `.github/workflows/lint.yml`):

```bash
uvx ruff@0.15.0 check src tests
git ls-files -z -- '*.sh' | xargs -0 shellcheck --severity=error
```

After changing dependencies in `pyproject.toml`, regenerate the hashed audit snapshot or the dependency-audit check fails:

```bash
uv pip compile pyproject.toml --extra test --universal --upgrade --generate-hashes --quiet --no-header --output-file .github/security-audit-requirements.txt
```

## 5. Architecture rules

Dependency direction within the CLI:

- A command lives in `command_<name>.py`. It owns the Typer handler, option parsing, rendering, and exit codes. It must not contain semantic validation or side effects that another adapter also needs.
- Operations shared by the CLI and MCP go in `_operation_<name>.py` (optionally `_operation_<name>_<phase>.py`). Both adapters call that entry point with a typed request and receive a typed outcome.
- Adapters never call or parse each other. Never call a Typer handler from MCP, and never call an MCP tool from the CLI.
- Command groups register their commands explicitly in `_commands.py`. Do not put decorated handlers in `_commands.py` or in package `__init__.py`.
- Pass project paths explicitly. Shared code must not call `os.chdir()`.
- Subprocess calls must not use `shell=True`. Ruff rules S602, S604, and S605 enforce this; any exception needs a `# noqa` with a reason.

New code placement:
- New CLI command: `command_<name>.py` in its group, registered in that group's `_commands.py`.
- New workflow step type: follow `design/workflow-step.md` for registration, validation, execution, and resume.
- New agent integration: follow `design/integration.md`. It owns install and uninstall of its files.

## 6. Conventions

- Branches: `<type>/<issue>-<slug>` when an issue exists, otherwise `<type>/<slug>`. Types: `feat`, `fix`, `docs`, `community`, `chore`.
- Commits: each agent-authored commit carries an `Assisted-by:` trailer naming the agent, model, and whether it ran `autonomous` or `supervised`. Do not remove tool-generated `Co-authored-by:` trailers.
- AI disclosure: PR descriptions, agent-authored commits, and AI-generated PR comments each need their own disclosure. Read `CONTRIBUTING.md` → "Agent-authored Git and review activity" first.
- Gitignored dogfooding output (`.github/agents/`, `.github/prompts/`, `.specify/`, `specs/`) must not be committed.

## 7. Testing policy

- Behavioral changes need positive tests and at least one negative test (invalid input, failure, or prevented behavior).
- Bug fixes need a regression test that fails before the fix and passes after it.
- PowerShell changes must work on Windows PowerShell 5.1, not only pwsh 7, and must match the Bash and Python behavior. Include 5.1 evidence in the PR.
- Changes to a slash command's behavior need manual testing through a real agent, with results in the PR (see `CONTRIBUTING.md` → Manual testing).
- Prompt-only text edits do not need invented tests.

## 8. Constraints and do-nots

- Never commit or print secrets, tokens, or credentials.
- Do not add a runtime dependency without asking the user first.
- Do not edit packaged copies under `core_pack/`. Edit the sources.
- Do not add an unrelated refactor to a feature or fix PR. Ask before large refactors.
- Do not resolve PR review conversations on a reviewer's behalf.
- Do not treat dogfooding artifacts as part of the repo history.

## 9. Testing layout

- `tests/specify_cli/<area>/` mirrors the source tree.
- Command surfaces: `test_command_<name>.py`. Shared operations: `test_operation_<name>.py`. Domain code: `test_<subject>.py` (no leading underscore).
- Cross-cutting checks: `tests/` top level, `tests/contract/`, `tests/workflows/`.

## 10. Maintenance

- Update this file and `CLAUDE.md` together when a command, layer boundary, or contract they describe changes.
- Keep counts and version numbers out of prose unless a command regenerates them.
